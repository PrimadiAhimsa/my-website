import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

export default function PricingSection() {
  const packages = [
    {
      name: "Hemat 3x Cek",
      duration: "(7 Hari)",
      description: "Buat kamu yang lagi ngebut nyelesein tugas biar selesai tepat waktu",
      price: "Rp 9.999",
      quota: "3x cek plagiasi",
      benefits: [
        "Skip menu pembayaran",
        "Bisa cek sampai 800 halaman/file", 
        "Dapet token 3x cek plagiasi",
        "Hasil langsung dikirim ke whatsapp"
      ],
      popular: false
    },
    {
      name: "Praktis 10x Cek",
      duration: "(14 Hari)",
      description: "Buat kamu deadliners yang lagi ngerjain revisian dan nugas",
      price: "Rp 29.999",
      quota: "10x cek plagiasi",
      benefits: [
        "Skip menu pembayaran",
        "Bisa cek sampai 800 halaman/file",
        "Dapet token 10x cek plagiasi", 
        "Hasil langsung dikirim ke whatsapp"
      ],
      popular: true
    },
    {
      name: "Pro 30x Cek",
      duration: "(3 Bulan)",
      description: "Buat kamu mahasiswa akhir yang lagi skripsian biar gausa bolak balik cek plagiasi",
      price: "Rp 89.999",
      quota: "30x cek plagiasi",
      benefits: [
        "Skip menu pembayaran",
        "Bisa cek sampai 800 halaman/file",
        "Dapet token 30x cek plagiasi",
        "Hasil langsung dikirim ke whatsapp"
      ],
      popular: false
    },
    {
      name: "Ultimate 100x Cek", 
      duration: "(6 Bulan)",
      description: "Solusi buat kamu yang pengen cek buanyaaak dokumen",
      price: "Rp 249.999",
      quota: "100x cek plagiasi",
      benefits: [
        "Skip menu pembayaran",
        "Bisa cek sampai 800 halaman/file",
        "Dapet token 100x cek plagiasi",
        "Hasil langsung dikirim ke whatsapp"
      ],
      popular: false
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            💰 Pilih Paket
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {packages.map((pkg, index) => (
            <Card key={index} className={`relative ${pkg.popular ? 'ring-2 ring-blue-500 shadow-lg' : ''}`}>
              {pkg.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-500">
                  Paling Populer
                </Badge>
              )}
              
              <CardHeader className="text-center pb-4">
                <div className="text-2xl mb-2">💼</div>
                <CardTitle className="text-lg">
                  {pkg.name}
                  <br />
                  <span className="text-sm font-normal text-gray-600">{pkg.duration}</span>
                </CardTitle>
                <p className="text-sm text-gray-600 mt-2">{pkg.description}</p>
                <div className="text-2xl font-bold text-blue-600 mt-4">{pkg.price}</div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div>
                  <p className="font-semibold text-sm text-gray-700 mb-1">Kuota</p>
                  <p className="text-sm text-gray-600">✅ {pkg.quota}</p>
                </div>

                <Separator />

                <div>
                  <p className="font-semibold text-sm text-gray-700 mb-2">Benefit</p>
                  <ul className="space-y-1">
                    {pkg.benefits.map((benefit, idx) => (
                      <li key={idx} className="text-sm text-gray-600 flex items-start">
                        <span className="text-green-500 mr-2">✅</span>
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>

                <Button className={`w-full mt-6 ${pkg.popular ? 'bg-blue-600 hover:bg-blue-700' : 'bg-gray-800 hover:bg-gray-900'}`}>
                  Beli Paket
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}