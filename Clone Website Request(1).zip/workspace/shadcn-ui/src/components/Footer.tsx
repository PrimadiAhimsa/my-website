import { Button } from "@/components/ui/button";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between space-y-6 md:space-y-0">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <img src="/logo.png" alt="WINJOK Logo" className="w-10 h-10 object-contain" />
            <span className="text-xl font-bold text-white">WINJOK</span>
          </div>

          {/* Contact Info */}
          <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
            <a 
              href="https://wa.me/6282146583438" 
              className="flex items-center space-x-2 hover:text-green-400 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              <span className="text-green-400">📱</span>
              <span>6282146583438</span>
            </a>
            
            <a 
              href="https://instagram.com/manuru.id" 
              className="flex items-center space-x-2 hover:text-pink-400 transition-colors"
              target="_blank" 
              rel="noopener noreferrer"
            >
              <span className="text-pink-400">📷</span>
              <span>manuru.id</span>
            </a>
            
            <a 
              href="https://tiktok.com/@manuru_id"
              className="flex items-center space-x-2 hover:text-gray-300 transition-colors"
              target="_blank"
              rel="noopener noreferrer" 
            >
              <span>🎵</span>
              <span>manuru_id</span>
            </a>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-sm bg-[transparent] text-center font-sans opacity-100 text-[#FFFFFF]">
            © 2019 WINJOK. All rights reserved.
          </p>
        </div>
      </div>

      {/* Floating CS Button */}
      <div className="fixed bottom-6 right-6">
        <a 
          href="https://wa.me/6282146583438"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center w-14 h-14 rounded-full bg-green-500 hover:bg-green-600 shadow-lg transition-colors"
        >
          <img 
            src="/whatsapp.png" 
            alt="WhatsApp" 
            className="w-8 h-8 filter brightness-0 invert"
          />
        </a>
      </div>
    </footer>
  );
}

