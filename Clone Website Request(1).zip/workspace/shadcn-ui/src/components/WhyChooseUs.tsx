import { Card, CardContent } from "@/components/ui/card";

export default function WhyChooseUs() {
  const features = [
    {
      icon: "🕒",
      title: "manuruID stay tuned terus buat kamu kok",
      description: "Layanan manuruID buka 24 jam, jadi ngga perlu khawatir kamu bisa cek Plagiasi kapanpun"
    },
    {
      icon: "⚡",
      title: "Hasilnya cepet dan otomatis", 
      description: "Prosesnya udah otomatis semua kamu tinggal duduk manis menunggu hasilnya"
    },
    {
      icon: "💬",
      title: "Adminnya responsif dan baik hati",
      description: "Kalo kamu bingung silakan klik icon CS disamping kanan, ntar langsung diarahin ke whatsapp Admin. Kamu bebas tanya apa aja!"
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-[transparent] text-center font-sans opacity-100 text-[#000000]">
            Emang kenapa harus WINJOK?
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow bg-white/80 backdrop-blur">
              <CardContent className="p-8">
                <div className="text-5xl mb-6">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-4 bg-[transparent] text-center font-sans opacity-100 text-[#FF0404]">
                  {feature.title}
                </h3>
                <p className="leading-relaxed bg-[transparent] text-left font-sans opacity-100 text-[transparent]">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}




