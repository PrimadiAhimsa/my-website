import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";

export default function TestimonialsSection() {
  const testimonials = [
    {
      name: "Nanda",
      university: "Institut Pertanian Bogor", 
      message: "Bagus banget, hasilnya cepet kluar ga nyampe 10 menittt",
      avatar: "N"
    },
    {
      name: "Bulan",
      university: "UIN",
      message: "Gercep bett, mantapp. Menyala manuru",
      avatar: "B"
    },
    {
      name: "Yoga Rizqy Firdiansyah",
      university: "Universitas Negeri Surabaya",
      message: "Salah satu agensi jasa kebutuhan tugas perkuliahan yang sangat profesional",
      avatar: "Y"
    },
    {
      name: "Gagah Pribadi", 
      university: "Universitas Negeri Malang",
      message: "Sumpah ini parafrase ngerjainnya cepet banget. Pemilihan kalimatnya bagus. Terus sesuai request persentase. Makasih Manuru. ♥️",
      avatar: "G"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
            Kata Mereka
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <Avatar>
                    <AvatarImage src="" />
                    <AvatarFallback className="bg-blue-100 text-blue-600">
                      {testimonial.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.university}</p>
                  </div>
                </div>
                
                <Separator className="mb-4" />
                
                <p className="text-gray-700 text-sm leading-relaxed">
                  "{testimonial.message}"
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}