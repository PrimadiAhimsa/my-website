import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-blue-50 to-indigo-50 py-16">
      {/* Important Notice Alert */}
      <div className="bg-red-500 text-white text-center py-3 px-4 animate-pulse">
        <p className="text-sm font-medium">
          📢 INFO PENTING ‼️ SEGERA DOWNLOAD HASIL CEK PLAGIASI KAMU DI MENU "CEK PESANAN" POJOK KANAN ATAS, FILE HASIL AKAN EXPIRED DALAM 24 JAM!!!
        </p>
      </div>

      <div className="container mx-auto px-4 pt-16 bg-[transparent] text-left font-sans opacity-100 text-[transparent]">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
                Layanan Cek Plagiasi #1 di Indonesia
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold bg-[transparent] text-left font-sans opacity-100 text-[#000000]">
                WINJOK itu apa sih?
              </h1>
              <p className="text-lg leading-relaxed bg-[transparent] text-left font-sans opacity-100 text-[#000000]">
                WINJOK adalah layanan cek plagiasi otomatis yang terintegrasi langsung dengan berbagai sumber dokumen di Internet, publikasi, dan direktori sehingga bisa mendeteksi tingkat plagiasi pada dokumen kamu
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8">
                Mulai Cek Plagiasi
              </Button>
              <Button size="lg" variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                Pelajari Lebih Lanjut
              </Button>
            </div>
          </div>

          {/* Right Illustration */}
          <div className="relative">
            <Card className="p-8 bg-white/80 backdrop-blur">
              <div className="aspect-square bg-gradient-to-br from-blue-400 to-indigo-500 rounded-2xl flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="text-6xl mb-4">📄</div>
                  <p className="text-xl font-semibold">Cek Plagiasi</p>
                  <p className="text-sm opacity-90">Otomatis & Akurat</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}


