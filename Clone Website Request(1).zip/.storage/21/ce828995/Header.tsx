import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isJasaDropdownOpen, setIsJasaDropdownOpen] = useState(false);
  return (
    <header className="w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center space-x-2">
          <img src="/logo.png" alt="WINJOK Logo" className="w-10 h-10 object-contain" />
          <span className="text-xl font-bold text-gray-900">WINJOK</span>
        </div>

        {/* Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <Button variant="ghost" className="text-gray-700 hover:text-blue-600">
            Cek Pesanan
          </Button>
          <Button variant="ghost" className="text-gray-700 hover:text-blue-600">
            Cara Order
          </Button>
          
          <div className="relative">
            <Button 
              variant="ghost" 
              className="text-gray-700 hover:text-blue-600 flex items-center"
              onClick={() => setIsJasaDropdownOpen(!isJasaDropdownOpen)}
              onMouseEnter={() => setIsJasaDropdownOpen(true)}
              onMouseLeave={() => setIsJasaDropdownOpen(false)}
            >
              Jasa winjok
              <svg className="ml-1 h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </Button>
            {isJasaDropdownOpen && (
              <div 
                className="absolute top-full left-0 mt-1 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-50"
                onMouseEnter={() => setIsJasaDropdownOpen(true)}
                onMouseLeave={() => setIsJasaDropdownOpen(false)}
              >
                <div className="p-2 space-y-1">
                  <a href="#" className="block px-3 py-2 text-sm text-gray-600 hover:text-blue-600 hover:bg-gray-50 rounded">
                    Cek Plagiasi
                  </a>
                  <a href="#" className="block px-3 py-2 text-sm text-gray-600 hover:text-blue-600 hover:bg-gray-50 rounded">
                    Parafrase
                  </a>
                </div>
              </div>
            )}
          </div>

          <Button className="bg-blue-600 hover:bg-blue-700 text-white">
            🔒 Login
          </Button>
        </nav>

        {/* Mobile menu button */}
        <Button 
          variant="ghost" 
          className="md:hidden"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </Button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200 shadow-lg">
          <div className="px-6 py-4 space-y-4">
            <Button variant="ghost" className="w-full justify-start text-gray-700 hover:text-blue-600">
              Cek Pesanan
            </Button>
            <Button variant="ghost" className="w-full justify-start text-gray-700 hover:text-blue-600">
              Cara Order
            </Button>
            <div className="space-y-2">
              <div className="text-sm font-medium text-gray-900 px-4">Jasa winjok</div>
              <div className="pl-4 space-y-2">
                <a href="#" className="block text-sm text-gray-600 hover:text-blue-600 px-4 py-2">
                  Cek Plagiasi
                </a>
                <a href="#" className="block text-sm text-gray-600 hover:text-blue-600 px-4 py-2">
                  Parafrase
                </a>
              </div>
            </div>
            <div className="pt-2 border-t border-gray-200">
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                🔒 Login
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}




